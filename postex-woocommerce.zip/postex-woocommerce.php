<?php
/*
Plugin Name: PostEx WooCommerce Integration
Description: Create PostEx shipments and fetch airway bills directly from WooCommerce admin.
Version: 1.0.0
Author: Muhammad Ahmad Alauddin
License: GPL2
*/

if (!defined('ABSPATH')) exit;

// Phase 3: PostEx API Client
class PostEx_Client {
    private $api_key;
    private $base_url;

    public function __construct() {
        $api_key1 = get_option('woocommerce_shipping_postex_api_key', '');
        $api_key2 = get_option('woocommerce_postex_api_key', '');
        $api_key3 = get_option('postex_api_key', '');
        
        $this->api_key = $api_key1 ?: $api_key2 ?: $api_key3;
        $this->base_url = 'https://api.postex.pk/';
    }

    public function create_order($payload) {
        $url = $this->base_url . 'services/integration/api/order/v3/create-order';
        $args = [
            'headers' => [
                'token' => $this->api_key,
                'Content-Type'  => 'application/json',
                'Accept' => 'application/json',
            ],
            'body'    => wp_json_encode($payload),
            'timeout' => 20,
        ];
        $response = wp_remote_post($url, $args);
        return $response;
    }

    // Stubs for later phases
    public function list_unbooked() { return []; }
    public function download_awb($tracking_numbers) { return null; }
}

// Activation/Deactivation Hooks
register_activation_hook(__FILE__, 'postex_wc_activate');
register_deactivation_hook(__FILE__, 'postex_wc_deactivate');

function postex_wc_activate() {
    // Activation logic (e.g., default options)
}

function postex_wc_deactivate() {
    // Deactivation logic
}

// Add settings tab to WooCommerce Shipping
add_filter('woocommerce_get_sections_shipping', 'postex_wc_add_settings_section');
function postex_wc_add_settings_section($sections) {
    $sections['postex'] = __('PostEx', 'postex-wc');
    return $sections;
}

add_filter('woocommerce_get_settings_shipping', 'postex_wc_settings', 10, 2);
function postex_wc_settings($settings, $current_section) {
    if ($current_section == 'postex') {
        $settings = array(
            array(
                'title' => __('PostEx Settings', 'postex-wc'),
                'type'  => 'title',
                'desc'  => '',
                'id'    => 'postex_settings_title'
            ),
            array(
                'title'    => __('API Key', 'postex-wc'),
                'desc'     => __('Enter your PostEx API key.', 'postex-wc'),
                'id'       => 'postex_api_key',
                'type'     => 'text',
                'default'  => '',
                'desc_tip' => true,
            ),
            array(
                'title'    => __('Pickup Address', 'postex-wc'),
                'id'       => 'postex_pickup_address',
                'type'     => 'textarea',
                'default'  => '',
            ),
            array(
                'title'    => __('Next Ref Number', 'postex-wc'),
                'id'       => 'postex_next_ref_number',
                'type'     => 'number',
                'default'  => 1000,
            ),
            array(
                'title'    => __('Auto Increment Ref #', 'postex-wc'),
                'id'       => 'postex_auto_increment',
                'type'     => 'checkbox',
                'default'  => 'yes',
            ),
            array(
                'type' => 'sectionend',
                'id'   => 'postex_settings_end'
            ),
        );
    }
    return $settings;
}

// Phase 2: Add order action button and enqueue modal assets

// Add a meta box with the Create PostEx Order button on the order edit screen
add_action('add_meta_boxes', function() {
    add_meta_box(
        'postex_wc_order_box',
        __('PostEx Shipment', 'postex-wc'),
        function($post) {
            $order = wc_get_order($post->ID);
            if ($order && !$order->get_meta('_postex_tracking')) {
                echo '<button type="button" class="button button-primary postex_create" style="margin-bottom:10px;">🚚 ' . esc_html__('Create PostEx Order', 'postex-wc') . '</button>';
            } else if ($order) {
                echo '<p style="color:green;">' . esc_html__('PostEx order already created.', 'postex-wc') . '</p>';
            }
        },
        'shop_order',
        'side',
        'high'
    );
});

// 2. Enqueue React/JS modal assets only on order admin screens
add_action('admin_enqueue_scripts', 'postex_wc_enqueue_admin_assets');
function postex_wc_enqueue_admin_assets($hook) {
    global $pagenow;
    if ($pagenow === 'post.php' && isset($_GET['post']) && get_post_type($_GET['post']) === 'shop_order') {
        wp_enqueue_script(
            'postex-wc-modal',
            plugins_url('assets/js/postex-modal.js', __FILE__),
            array('wp-element', 'jquery'),
            '1.0.0',
            true
        );
        wp_localize_script('postex-wc-modal', 'PostExWC', array(
            'nonce' => wp_create_nonce('postex_wc_order_action'),
            'order_id' => intval($_GET['post'])
        ));
    }
}


// 5. AJAX handler for creating PostEx order
add_action('wp_ajax_postex_wc_create_order', 'postex_wc_ajax_create_order');
function postex_wc_ajax_create_order() {
    // Correct nonce check; this also sanitizes $_POST['nonce']
    if (!check_ajax_referer('postex_wc_order_action', 'nonce', false)) {
        wp_send_json_error(['message' => 'Invalid nonce.']);
    }
    $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
    $weight = isset($_POST['weight']) ? floatval($_POST['weight']) : 1;

    file_put_contents(__DIR__ . '/postex-api-debug.log', 'Request received: ' . json_encode($_POST) . "\n", FILE_APPEND);

    if (!$order_id || !$weight) {
        wp_send_json_error(['message' => 'Invalid order or weight.']);
    }
    $order = wc_get_order($order_id);
    if (!$order) {
        wp_send_json_error(['message' => 'Order not found.']);
    }

    // Map Woo order data to PostEx payload
    $ref_number = get_option('woocommerce_shipping_postex_next_ref_number', 1000);
    $payload = [
        'orderRefNumber' => $ref_number,
        'codAmount'      => floatval($order->get_total()),
        'weight'         => $weight,
        'dimensions'     => [ 'length' => 10, 'width' => 10, 'height' => 10 ], // Placeholder
        'recipient'      => [
            'name'    => $order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name(),
            'phone'   => $order->get_billing_phone(),
            'address' => $order->get_shipping_address_1(),
            'city'    => $order->get_shipping_city(),
        ],
        // Add more fields as needed
    ];

    $client = new PostEx_Client();
    
    // Debug API key - try multiple possible setting keys
    $api_key1 = get_option('woocommerce_shipping_postex_api_key', '');
    $api_key2 = get_option('woocommerce_postex_api_key', '');
    $api_key3 = get_option('postex_api_key', '');
    
    $api_key = $api_key1 ?: $api_key2 ?: $api_key3;
    
    file_put_contents(__DIR__ . '/postex-api-debug.log', 
        "API Key attempts:\n" .
        "woocommerce_shipping_postex_api_key: " . ($api_key1 ? substr($api_key1, 0, 10) . "..." : 'EMPTY') . "\n" .
        "woocommerce_postex_api_key: " . ($api_key2 ? substr($api_key2, 0, 10) . "..." : 'EMPTY') . "\n" .
        "postex_api_key: " . ($api_key3 ? substr($api_key3, 0, 10) . "..." : 'EMPTY') . "\n" .
        "Final API Key: " . ($api_key ? substr($api_key, 0, 10) . "..." : 'EMPTY') . "\n",
        FILE_APPEND
    );
    
    if (empty($api_key)) {
        wp_send_json_error(['message' => 'PostEx API key not configured. Go to WooCommerce → Settings → Shipping → PostEx']);
    }
    
    $response = $client->create_order($payload);

    // Error check for WP_Error from API call
    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $log_path = WP_CONTENT_DIR . '/postex-api-debug.log';
            file_put_contents($log_path, date('c') . "\nAPI ERROR: $error_message\n\n", FILE_APPEND);
        }
        wp_send_json_error(['message' => 'API error: ' . $error_message]);
    }
    $code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $json = json_decode($body, true);

    // Enhanced logging for diagnostics
    $log_path = WP_CONTENT_DIR . '/postex-api-debug.log';
    file_put_contents(
        $log_path,
        date('c') .
        "\nAPI Key: " . substr($this->api_key, 0, 10) . "..." .
        "\nRequest URL: " . $url .
        "\nRequest Payload: " . print_r($payload, true) .
        "\nRequest Headers: " . print_r($args['headers'], true) .
        "\nResponse Code: " . $code .
        "\nRaw Body: " . $body .
        "\nParsed JSON: " . print_r($json, true) . "\n\n",
        FILE_APPEND
    );

    if ($code === 200 && !empty($json['trackingNumber'])) {
        $order->update_meta_data('_postex_tracking', $json['trackingNumber']);
        $order->update_meta_data('_postex_payload', $payload);
        $order->save();
        $order->add_order_note('PostEx order created – TN ' . $json['trackingNumber']);
        // Increment next_ref_number
        update_option('woocommerce_shipping_postex_next_ref_number', $ref_number + 1);
        wp_send_json_success(['tracking_number' => $json['trackingNumber']]);
    } else {
        $msg = isset($json['message']) ? $json['message'] : $body;
        wp_send_json_error(['message' => $msg]);
    }
}
