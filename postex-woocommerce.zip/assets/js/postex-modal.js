
(function($){
    $(document).ready(function(){
        // Listen for click on the custom order action button
        $(document).on('click', '.postex_create', function(e){
            e.preventDefault();
            if ($('#postex-modal').length === 0) {
                const modalHtml = `
                <div id="postex-modal" style="position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.5);z-index:9999;display:flex;align-items:center;justify-content:center;">
                  <div style="background:#fff;padding:2em;min-width:350px;min-height:120px;position:relative;border-radius:8px;box-shadow:0 2px 16px rgba(0,0,0,0.2);">
                    <button id="postex-modal-close" style="position:absolute;top:10px;right:10px;background:none;border:none;font-size:1.5em;cursor:pointer;">&times;</button>
                    <h2 style="margin-top:0;">Create PostEx Order</h2>
                    <div id="postex-modal-content">
                      <p><strong>Order ID:</strong> ${PostExWC.order_id}</p>
                      <div style="margin:1em 0;">
                        <label for="postex-weight">Weight (kg): </label>
                        <input type="number" id="postex-weight" min="0.1" step="0.1" value="1" style="width:60px;">
                      </div>
                      <button id="postex-create-order" style="background:#007cba;color:#fff;padding:0.5em 1.5em;border:none;border-radius:4px;cursor:pointer;">Create Order</button>
                      <span id="postex-modal-status" style="margin-left:1em;"></span>
                    </div>
                  </div>
                </div>`;
                $('body').append(modalHtml);
            }
        });
        // Close modal
        $(document).on('click', '#postex-modal-close', function(){
            $('#postex-modal').remove();
        });
        // AJAX handler for Create Order
        $(document).on('click', '#postex-create-order', function(){
            var weight = parseFloat($('#postex-weight').val()) || 1;
            $('#postex-modal-status').text('Sending request...');
            $.ajax({
                url: ajaxurl,
                method: 'POST',
                dataType: 'json',
                data: {
                    action: 'postex_wc_create_order',
                    nonce: PostExWC.nonce,
                    order_id: PostExWC.order_id,
                    weight: weight
                },
                success: function(response) {
                    if (response.success) {
                        $('#postex-modal-status').css('color','green').text('Order created! Tracking #: ' + response.data.tracking_number);
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } else {
                        $('#postex-modal-status').css('color','red').text(response.data && response.data.message ? response.data.message : 'Failed to create order.');
                    }
                },
                error: function(xhr) {
                    $('#postex-modal-status').css('color','red').text('AJAX error.');
                }
            });
        });
    });
})(jQuery);
